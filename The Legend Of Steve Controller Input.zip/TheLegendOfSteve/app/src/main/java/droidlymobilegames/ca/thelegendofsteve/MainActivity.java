package droidlymobilegames.ca.thelegendofsteve;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;

public class MainActivity extends AppCompatActivity {

    GameviewActivity gameviewActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameviewActivity = new GameviewActivity(this);
        setContentView(gameviewActivity);
    }
    @Override
    protected void onPause() {
        super.onPause();
        gameviewActivity.gameLoop.stopLoop();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        boolean handled = false;
        String getkeypressed = String.valueOf(event.getKeyCode());
        System.out.println("GET POOP CHEESE " + keyCode);

        if (event.getRepeatCount() == 0) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BUTTON_A:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_B:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_Y:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_X:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_L1:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_L2:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_R1:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_R2:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_START:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_SELECT:

                    return false;
                case 19://UP
                    gameviewActivity.player.entityUp = true;
                    return false;
                case 20://DOWN
                    gameviewActivity.player.entityDown = true;
                    return false;
                case 21://LEFT
                    gameviewActivity.player.entityLeft = true;
                    return false;
                case 22://RIGHT
                    gameviewActivity.player.entityRight = true;
                    return false;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp (int keyCode, KeyEvent event){
        //HANDLE WHEN BUTTON RELEASED
        gameviewActivity.player.entityRight = false;
        gameviewActivity.player.entityDown = false;
        gameviewActivity.player.entityUp = false;
        gameviewActivity.player.entityLeft = false;
        return super.onKeyUp(keyCode, event);
    }
    @Override
    public boolean onGenericMotionEvent(MotionEvent event) {

        if (event.getAxisValue(MotionEvent.AXIS_X) > .99d) {
            //JOYSTICK RIGHT
        } else {
            if (event.getAxisValue(MotionEvent.AXIS_Y) > .99d) {
                //JOYSTICK DOWN
            } else {
                if (event.getAxisValue(MotionEvent.AXIS_X) < -.99d) {
                    //JOYSTICK LEFT
                } else {
                    if (event.getAxisValue(MotionEvent.AXIS_Y) < -.99d) {
                        //JOYSTICK UP
                    } else {
                        //SET PLAYER IDLE SET ALL OTHER ACTIONS FALSE
                    }
                }
            }
        }
        return super.onGenericMotionEvent(event);
    }
}