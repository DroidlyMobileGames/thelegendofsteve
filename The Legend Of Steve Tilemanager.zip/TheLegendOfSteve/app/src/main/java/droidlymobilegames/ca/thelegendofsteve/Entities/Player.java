package droidlymobilegames.ca.thelegendofsteve.Entities;

import droidlymobilegames.ca.thelegendofsteve.GameviewActivity;
import droidlymobilegames.ca.thelegendofsteve.R;
import droidlymobilegames.ca.thelegendofsteve.Tools.Helpers;

public class Player extends EntityInfo{

    public Player(GameviewActivity game){
        this.game = game;
        entityWidth = 160;
        entityHeight = 160;
        setupSpritesheet(R.drawable.character1_spritesheet1);
        screenX = new Helpers(game).getDisplayWidth()/2 - 80;
        screenY = new Helpers(game).getDisplayHeight()/2 - 80;
        defaultImg = sprites[0];
    }
}
