package droidlymobilegames.ca.thelegendofsteve;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    GameviewActivity gameviewActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameviewActivity = new GameviewActivity(this);
        setContentView(gameviewActivity);
    }
    @Override
    protected void onPause() {
        super.onPause();
        gameviewActivity.gameLoop.stopLoop();
    }
}