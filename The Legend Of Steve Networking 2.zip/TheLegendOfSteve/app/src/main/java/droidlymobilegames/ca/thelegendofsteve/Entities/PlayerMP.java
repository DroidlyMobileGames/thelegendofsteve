package droidlymobilegames.ca.thelegendofsteve.Entities;

import java.net.InetAddress;

import droidlymobilegames.ca.thelegendofsteve.R;

public class PlayerMP extends EntityInfo{

    public InetAddress ipAddress;
    public int port;
    public PlayerMP(int x, int y, String username, InetAddress ipAddress, int port) {
        this.ipAddress = ipAddress;
        this.port = port;
        entityWidth = 160;
        entityHeight = 160;
        posX = x;
        posY = y;
        username = username;
        setupSpritesheet(R.drawable.character1_spritesheet1);
        defaultImg = sprites[0];
    }
}
