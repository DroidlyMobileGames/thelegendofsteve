package droidlymobilegames.ca.thelegendofsteve;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.nio.charset.StandardCharsets;

import droidlymobilegames.ca.thelegendofsteve.Net.GameClient;

public class MainActivity extends AppCompatActivity {

    GameviewActivity gameviewActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameviewActivity = new GameviewActivity(this);
        setContentView(gameviewActivity);


    }
    @Override
    protected void onPause() {
        super.onPause();
        gameviewActivity.gameLoop.stopLoop();
    }
}