package droidlymobilegames.ca.thelegendofsteve.World;

import android.graphics.Canvas;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import droidlymobilegames.ca.thelegendofsteve.GameviewActivity;
import droidlymobilegames.ca.thelegendofsteve.R;

public class TileManager extends TileInfo{

    public TileInfo[] tiles = new TileInfo[100];

    public TileManager (GameviewActivity game){
        this.game = game;
        setupTilesheet(R.drawable.overworld_main);
        worldTileNum = new int[game.worldXSize][game.worldYSize];//max world size x and y
        loadWorldMap("");
    }
    public void drawTiles(Canvas canvas){
        int tileCol = 0;
        int tileRow = 0;
        while (tileCol < game.worldXSize && tileRow < game.worldYSize){
            tileNum = worldTileNum[tileCol][tileRow];//Gets the tileNum at the XY position from the txt data
            int tileWorldX = tileCol * game.tileSize;//Sets the tile at the position X in the world times the scaled tilesize 160 in example
            int tileWorldY = tileRow * game.tileSize;//Sets position Y times scaled tilesize
            int tileScreenX = tileWorldX - game.player.posX + game.player.screenX;
            int tileScreenY = tileWorldY - game.player.posY + game.player.screenY;

            if (tileWorldX + game.cameraWidth > game.player.worldX - game.player.screenX &&
                    tileWorldX - game.cameraWidth < game.player.worldX + game.player.screenX &&
                    tileWorldY + game.cameraHeight > game.player.worldY - game.player.screenY &&
                    tileWorldY - game.cameraHeight < game.player.worldY + game.player.screenY){
                if (tiles[tileNum].defaultTileImg != null) {
                    canvas.drawBitmap(tiles[tileNum].defaultTileImg, tileScreenX, tileScreenY, null);
                }
            }
            tileCol ++;

            if (tileCol == game.worldXSize){//Check if tileCol reaches the end in this case 100 tiles then resets back to 0 then increases rows
                tileCol = 0;
                tileRow++;
            }
        }

    }

    public void loadWorldMap(final String _mapname){//Used to load map from the raw folder in res
        try {
            inputStream = game.getContext().getResources().openRawResource(
                    game.getContext().getResources().getIdentifier(
                            _mapname,"raw", game.getContext().getPackageName()));
            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            int column = 0;
            int row = 0;
            while (column< game.worldXSize && row < game.worldYSize){
                String line = bufferedReader.readLine();
                while (column < game.worldXSize){
                    //Splits the line to read the data from the text
                    String[] numbers = line.split(" ");
                    int num = Integer.parseInt(numbers[column]);
                    worldTileNum[column][row]= num;
                    column ++;
                }
                if (column == game.worldXSize){
                    column = 0;
                    row ++;
                }
            }
            bufferedReader.close();
        }catch (Exception e){
        }
        setUpTileInfo();
    }
    public void setUpTileInfo(){//This is used to check tiles that are collidable
        //collisionTiles.add(String.valueOf(1));
       // for (int tileID = 0; tileID<tilesList.size(); tileID++){
            tiles[0] = new TileInfo();
            tiles[0].defaultTileImg = tileImgs[0];
            tiles[0].tileWidth = game.tileSize;
            tiles[0].tileHeight = game.tileSize;
           // if (collisionTiles.contains(String.valueOf((int)tileID))){
            //    tileInfo[tileID].tileCollision = true;
           // }
       // }
    }
}
