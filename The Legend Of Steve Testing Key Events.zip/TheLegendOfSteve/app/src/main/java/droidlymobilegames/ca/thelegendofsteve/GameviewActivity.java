package droidlymobilegames.ca.thelegendofsteve;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import androidx.annotation.NonNull;
import droidlymobilegames.ca.thelegendofsteve.Entities.Player;
import droidlymobilegames.ca.thelegendofsteve.Tools.Helpers;
import droidlymobilegames.ca.thelegendofsteve.World.TileManager;

public class GameviewActivity extends SurfaceView implements SurfaceHolder.Callback{

    SurfaceHolder surfaceHolder;
    public GameLoop gameLoop;
    public Player player;
    public int worldXSize,worldYSize;
    public int tileSize,cameraWidth,cameraHeight = 0;
    public int keypressed = -1;
    public TileManager tileManager;
    public boolean buttonPressed = false;

    public Paint textpaint = new Paint();


    public GameviewActivity(Context context) {
        super(context);
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
        gameLoop = new GameLoop(this,surfaceHolder);
        player = new Player(this);

        worldXSize = 100;
        worldYSize = 100;
        tileSize = 160;
        cameraWidth = new Helpers(this).getDisplayWidth();
        cameraHeight = new Helpers(this).getDisplayHeight();
        tileManager = new TileManager(this);

        textpaint.setTextSize(50);
        textpaint.setColor(Color.BLUE);
    }

    public void update(){
        player.update();
        //gameClient.sendData("HELLO WORLD".getBytes(StandardCharsets.UTF_8));
    }
    public void draw(Canvas canvas){
        super.draw(canvas);
        tileManager.drawTiles(canvas);
        player.draw(canvas);
        canvas.drawText(String.valueOf(keypressed),100,100,textpaint);
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        if (gameLoop.getState().equals(Thread.State.TERMINATED)){
            surfaceHolder = getHolder();
            surfaceHolder.addCallback(this);
            gameLoop = new GameLoop(this,surfaceHolder);
        }
        gameLoop.startLoop();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {

    }

}
