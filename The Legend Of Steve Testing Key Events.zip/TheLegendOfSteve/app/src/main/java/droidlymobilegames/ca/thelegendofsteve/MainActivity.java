package droidlymobilegames.ca.thelegendofsteve;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GameviewActivity gameviewActivity;
    public ArrayList<String> buttonlist = new ArrayList<>();
    public ArrayList<String> buttonkeylist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameviewActivity = new GameviewActivity(this);
        setContentView(gameviewActivity);
    }
    @Override
    protected void onPause() {
        super.onPause();
        gameviewActivity.gameLoop.stopLoop();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        boolean handled = false;
        String getkeypressed = String.valueOf(event.getKeyCode());
        gameviewActivity.keypressed = event.getRepeatCount();
        checkButtonsPressed(keyCode);
        System.out.println("GET POOP CHEESE " + keyCode);

        /*if (event.getRepeatCount() == 0) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BUTTON_A:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_B:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_Y:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_X:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_L1:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_L2:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_R1:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_R2:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_START:

                    return false;
                case KeyEvent.KEYCODE_BUTTON_SELECT:

                    return false;
                case 19://UP
                    //gameviewActivity.player.entityUp = true;
                    return false;
                case 20://DOWN
                    //gameviewActivity.player.entityDown = true;
                    return false;
                case 21://LEFT
                    //gameviewActivity.player.entityLeft = true;
                    return false;
                case 22://RIGHT
                    //gameviewActivity.player.entityRight = true;
                    return false;
            }
        }*/
        return super.onKeyDown(keyCode, event);
    }

    private void checkButtonsPressed(int keyCode) {
        try {
            if (keyCode == 21 &&
                    !buttonlist.contains("LEFT BUTTON") &&
                    !buttonlist.contains("DOWN BUTTON")) {
                buttonlist.add("LEFT BUTTON");
            } else if (keyCode == 20 &&
                    !buttonlist.contains("LEFT BUTTON") &&
                    !buttonlist.contains("DOWN BUTTON")) {
                buttonlist.add("DOWN BUTTON");
            }
            buttonkeylist.add(String.valueOf(keyCode));

            //CHECK BUTTON HANDLE BUTTON
            if (buttonlist.contains("LEFT BUTTON")) {
                gameviewActivity.player.entityLeft = true;
            } else if (buttonlist.contains("DOWN BUTTON")) {
                gameviewActivity.player.entityDown = true;
            }
        }catch (IllegalArgumentException iae){

        }
    }

    @Override
    public boolean onKeyUp (int keyCode, KeyEvent event){
        //HANDLE WHEN BUTTON RELEASED
        if (buttonkeylist.contains(String.valueOf(keyCode))) {
            handButtonsReleased(keyCode);
            buttonlist.remove(buttonkeylist.indexOf(String.valueOf(keyCode)));
            buttonkeylist.remove(buttonkeylist.indexOf(String.valueOf(keyCode)));
        }
        buttonkeylist.clear();
        System.out.println("GET MONKEY " + keyCode + " " + buttonlist + " " + buttonkeylist);
        return super.onKeyUp(keyCode, event);
    }

    private void handButtonsReleased(int keyCode) {
        String getKeyInfo = buttonlist.get(buttonkeylist.indexOf(String.valueOf(keyCode)));

        if (getKeyInfo.equals("LEFT BUTTON") ||
                getKeyInfo.equals("DOWN BUTTON")){
            gameviewActivity.player.entityLeft = false;
            gameviewActivity.player.entityDown = false;
            gameviewActivity.player.entityDirection = "none";
        }
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent event) {

        if (event.getAxisValue(MotionEvent.AXIS_X) > .99d) {
            //JOYSTICK RIGHT
        } else {
            if (event.getAxisValue(MotionEvent.AXIS_Y) > .99d) {
                //JOYSTICK DOWN
            } else {
                if (event.getAxisValue(MotionEvent.AXIS_X) < -.99d) {
                    //JOYSTICK LEFT
                } else {
                    if (event.getAxisValue(MotionEvent.AXIS_Y) < -.99d) {
                        //JOYSTICK UP
                    } else {
                        //SET PLAYER IDLE SET ALL OTHER ACTIONS FALSE
                    }
                }
            }
        }
        return super.onGenericMotionEvent(event);
    }
}