package droidlymobilegames.ca.thelegendofsteve.Entities;

import droidlymobilegames.ca.thelegendofsteve.GameviewActivity;
import droidlymobilegames.ca.thelegendofsteve.R;
import droidlymobilegames.ca.thelegendofsteve.Tools.Helpers;

public class Player extends EntityInfo{

    public Player(GameviewActivity game){
        this.game = game;
        entityWidth = 160;
        entityHeight = 160;
        setupSpritesheet(R.drawable.character1_spritesheet1);
        screenX = new Helpers(game).getDisplayWidth()/2 - 80;
        screenY = new Helpers(game).getDisplayHeight()/2 - 80;
        defaultImg = sprites[0];
        posX = 160 * 10;
        walkSpeed = 10;
    }
    public void update(){
        updatePlayerDirection();
        checkPlayerAction();
    }
    public void updatePlayerDirection(){
        if (entityRight){
            entityDirection = "right";
        }else if (entityLeft){
            entityDirection = "left";
        }else if (entityDown){
            entityDirection = "down";
        }else if (entityUp){
            entityDirection = "up";
        }else if (!game.buttonPressed){
            entityDirection = "none";
        }
    }
    public void checkPlayerAction(){
        switch (entityDirection){
            case "right":
                posX += walkSpeed;
                break;
            case "left":
                posX -= walkSpeed;
                break;
            case "down":
                posY += walkSpeed;
                break;
            case "up":
                posY -= walkSpeed;
                break;
        }
    }
}
