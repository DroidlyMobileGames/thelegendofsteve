package droidlymobilegames.ca.thelegendofsteve.GameController;

import android.view.KeyEvent;

import droidlymobilegames.ca.thelegendofsteve.GameviewActivity;
import droidlymobilegames.ca.thelegendofsteve.MainActivity;

public class Joystick implements MainActivity.JoystickListener{

    private int dPadCurrentLocation = KeyEvent.KEYCODE_DPAD_CENTER;

    @Override
    public boolean onButton(int buttonPress, boolean isPressed) {
        boolean handled = true;
        switch (buttonPress){
            case KeyEvent.KEYCODE_BUTTON_A:

                break;
            case KeyEvent.KEYCODE_BUTTON_B:

                break;
            case KeyEvent.KEYCODE_BUTTON_X:

                break;
            case KeyEvent.KEYCODE_BUTTON_Y:

                break;
            case KeyEvent.KEYCODE_BUTTON_START:

                break;
            case KeyEvent.KEYCODE_BUTTON_SELECT:

                break;
            case KeyEvent.KEYCODE_BUTTON_L1:

                break;
            case KeyEvent.KEYCODE_BUTTON_L2:

                break;
            case KeyEvent.KEYCODE_BUTTON_R1:

                break;
            case KeyEvent.KEYCODE_BUTTON_R2:
                break;
            case KeyEvent.KEYCODE_BUTTON_THUMBL:
                break;
            case KeyEvent.KEYCODE_BUTTON_THUMBR:
                break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
                dPadCurrentLocation = KeyEvent.KEYCODE_DPAD_CENTER;
                break;

            default:
                handled = false;
        }
        return handled;
    }

    @Override
    public void onJoystick(float[] joystickData) {
        //float translationX = Utility.mapFloat(joystickData[0], -1, 1, -40, 40);
        // float translationY = Utility.mapFloat(joystickData[1], -1, 1, -40, 40);
    }
}
